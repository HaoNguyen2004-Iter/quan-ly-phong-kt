import React, { useEffect, useState } from 'react';
import { Save, X } from 'lucide-react';

const emptyTask = {
    id: null,
    name: '',
    description: '',
    assignee: '',
    priority: 'Trung bình',    // Thấp | Trung bình | Cao
    status: 'Mới',             // Mới | Đang thực hiện | Hoàn thành | Tạm dừng | Quá hạn
    startDate: '',
    dueDate: '',
    tags: [],
};

export default function EditTask({ task = null, onSave, onCancel }) {
    const [form, setForm] = useState(emptyTask);
    const [tagInput, setTagInput] = useState('');

    useEffect(() => {
        if (task) {
            setForm({
                ...emptyTask,
                ...task,
                tags: Array.isArray(task.tags) ? task.tags : [],
            });
        } else {
            setForm(emptyTask);
        }
    }, [task]);

    const update = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

    const addTag = () => {
        const v = tagInput.trim();
        if (!v) return;
        if (!form.tags.includes(v)) update('tags', [...form.tags, v]);
        setTagInput('');
    };
    const removeTag = (t) => update('tags', form.tags.filter(x => x !== t));

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!form.name.trim()) {
            alert('Tên công việc là bắt buộc');
            return;
        }
        if (onSave) onSave(form);
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900">{form.id ? 'Chỉnh sửa công việc' : 'Thêm công việc'}</h2>
                    <button onClick={onCancel} className="inline-flex items-center gap-1 px-3 py-1 rounded-lg border hover:bg-gray-50">
                        <X className="w-4 h-4" /> Đóng
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div className="lg:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tên công việc *</label>
                        <input
                            value={form.name}
                            onChange={(e) => update('name', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="VD: Lập báo cáo tài chính Q4"
                        />
                    </div>

                    <div className="lg:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Mô tả</label>
                        <textarea
                            value={form.description}
                            onChange={(e) => update('description', e.target.value)}
                            rows={4}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Mô tả chi tiết công việc..."
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Người thực hiện</label>
                        <input
                            value={form.assignee}
                            onChange={(e) => update('assignee', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="VD: Nguyễn Văn A"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Ưu tiên</label>
                        <select
                            value={form.priority}
                            onChange={(e) => update('priority', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option>Thấp</option>
                            <option>Trung bình</option>
                            <option>Cao</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Trạng thái</label>
                        <select
                            value={form.status}
                            onChange={(e) => update('status', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option>Mới</option>
                            <option>Đang thực hiện</option>
                            <option>Hoàn thành</option>
                            <option>Tạm dừng</option>
                            <option>Quá hạn</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Ngày bắt đầu</label>
                        <input
                            type="date"
                            value={form.startDate || ''}
                            onChange={(e) => update('startDate', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Hạn chót</label>
                        <input
                            type="date"
                            value={form.dueDate || ''}
                            onChange={(e) => update('dueDate', e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div className="lg:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Thẻ (tags)</label>
                        <div className="flex gap-2">
                            <input
                                value={tagInput}
                                onChange={(e) => setTagInput(e.target.value)}
                                className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Nhập thẻ và Enter"
                                onKeyDown={(e) => e.key === 'Enter' ? (e.preventDefault(), addTag()) : null}
                            />
                            <button type="button" onClick={addTag} className="px-3 py-2 border rounded-lg hover:bg-gray-50">Thêm</button>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-2">
                            {form.tags.map(t => (
                                <span key={t} className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-gray-100 border rounded-full">
                                    {t}
                                    <button type="button" onClick={() => removeTag(t)} className="text-gray-500 hover:text-gray-800">×</button>
                                </span>
                            ))}
                        </div>
                    </div>

                    <div className="lg:col-span-2 flex justify-end gap-2 mt-2">
                        <button type="button" onClick={onCancel} className="px-4 py-2 border rounded-lg hover:bg-gray-50">Huỷ</button>
                        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 inline-flex items-center gap-2">
                            <Save className="w-4 h-4" /> Lưu
                        </button>
                    </div>
                </form>
            </div>
            </div>
    );
}
