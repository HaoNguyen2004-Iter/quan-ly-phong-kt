import React, { useMemo, useState } from 'react';
import { Calendar, Plus, Eye, Edit, Trash2, Check, X, Clock, FileText } from 'lucide-react';
import FilterBar from './common/FilterBar';
import { useLeaveStore } from '../store/leaveStore';

// ====== Form thêm/sửa ======
function LeaveForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(
    initial || {
      id: null,
      employeeName: '',
      employeeId: '',
      leaveType: 'Nghỉ phép năm',
      startDate: '',
      endDate: '',
      days: 1,
      reason: '',
      status: 'Chờ duyệt',
      submittedDate: new Date().toISOString().slice(0, 10),
      approver: '',
      avatar: '',
    }
  );

  const update = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const recomputeDays = (start, end) => {
    if (!start || !end) return;
    const s = new Date(start), e = new Date(end);
    const diff = Math.round((e - s) / (1000 * 60 * 60 * 24)) + 1;
    if (!Number.isNaN(diff) && diff > 0) update('days', diff);
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">
          {form.id ? 'Chỉnh sửa đơn nghỉ' : 'Tạo đơn nghỉ mới'}
        </h3>
        <button onClick={onCancel} className="px-3 py-1 rounded-lg border hover:bg-gray-50">Đóng</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Nhân viên *</label>
          <input
            value={form.employeeName}
            onChange={(e) => update('employeeName', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="VD: Nguyễn Văn A"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Mã NV</label>
          <input
            value={form.employeeId}
            onChange={(e) => update('employeeId', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="VD: NV001"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Loại nghỉ</label>
          <select
            value={form.leaveType}
            onChange={(e) => update('leaveType', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {['Nghỉ phép năm','Nghỉ ốm','Nghỉ việc riêng','Nghỉ thai sản','Nghỉ không lương','Nghỉ lễ tết'].map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Người duyệt</label>
          <input
            value={form.approver}
            onChange={(e) => update('approver', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="VD: Trần Thị B"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Bắt đầu *</label>
          <input
            type="date"
            value={form.startDate}
            onChange={(e) => { update('startDate', e.target.value); recomputeDays(e.target.value, form.endDate); }}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Kết thúc *</label>
          <input
            type="date"
            value={form.endDate}
            onChange={(e) => { update('endDate', e.target.value); recomputeDays(form.startDate, e.target.value); }}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Số ngày</label>
          <input
            type="number"
            min={1}
            value={form.days}
            onChange={(e) => update('days', parseInt(e.target.value || '1', 10))}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Trạng thái</label>
          <select
            value={form.status}
            onChange={(e) => update('status', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {['Chờ duyệt','Đã duyệt','Từ chối'].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Lý do</label>
          <textarea
            rows={3}
            value={form.reason}
            onChange={(e) => update('reason', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Lý do xin nghỉ..."
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onCancel} className="px-4 py-2 border rounded-lg hover:bg-gray-50">Huỷ</button>
        <button
          onClick={() => {
            if (!form.employeeName || !form.startDate || !form.endDate) {
              alert('Vui lòng nhập Nhân viên, Bắt đầu, Kết thúc.');
              return;
            }
            onSave && onSave(form);
          }}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Lưu
        </button>
      </div>
    </div>
  );
}

// ====== Trang chính ======
const LeaveManagementPage = () => {
  const items     = useLeaveStore(s => s.items);
  const add       = useLeaveStore(s => s.add);
  const update    = useLeaveStore(s => s.update);
  const remove    = useLeaveStore(s => s.remove);
  const setStatus = useLeaveStore(s => s.setStatus);

  // Mở/đóng form
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing]   = useState(null);

  // Search + Filters
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState({ type: 'all', status: 'all', approver: 'all' });

  // Options
  const types     = useMemo(() => ['all', ...Array.from(new Set(items.map(r => r.leaveType)))], [items]);
  const statuses  = useMemo(() => ['all', ...Array.from(new Set(items.map(r => r.status)))], [items]);
  const approvers = useMemo(() => ['all', ...Array.from(new Set(items.map(r => r.approver)))], [items]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter(r => {
      const hit = !q ||
        r.employeeName.toLowerCase().includes(q) ||
        r.leaveType.toLowerCase().includes(q) ||
        r.approver.toLowerCase().includes(q);
      if (!hit) return false;
      if (filters.type !== 'all' && r.leaveType !== filters.type) return false;
      if (filters.status !== 'all' && r.status !== filters.status) return false;
      if (filters.approver !== 'all' && r.approver !== filters.approver) return false;
      return true;
    });
  }, [items, query, filters]);

  // CRUD
  const openCreate = () => { setEditing(null); setShowForm(true); };
  const openEdit   = (id) => { const it = items.find(x => x.id === id); if (it) { setEditing(it); setShowForm(true); } };
  const handleSave = (form) => {
    if (form.id == null) add(form);
    else update(form);
    setShowForm(false);
    setEditing(null);
  };
  const handleDelete = (id) => { if (confirm('Xoá đơn này?')) remove(id); };

  // Stats
  const stats = {
    total: items.length,
    pending: items.filter(r => r.status === 'Chờ duyệt').length,
    approved: items.filter(r => r.status === 'Đã duyệt').length,
    rejected: items.filter(r => r.status === 'Từ chối').length,
  };

  const getStatusColor = (s) => s === 'Đã duyệt' ? 'bg-green-100 text-green-800'
    : s === 'Chờ duyệt' ? 'bg-yellow-100 text-yellow-800'
    : s === 'Từ chối'   ? 'bg-red-100 text-red-800'
    : 'bg-gray-100 text-gray-800';

  const getLeaveTypeColor = (t) => t === 'Nghỉ phép năm' ? 'bg-blue-100 text-blue-800'
    : t === 'Nghỉ ốm' ? 'bg-red-100 text-red-800'
    : t === 'Nghỉ việc riêng' ? 'bg-purple-100 text-purple-800'
    : t === 'Nghỉ thai sản' ? 'bg-pink-100 text-pink-800'
    : 'bg-gray-100 text-gray-800';

  const StatCard = ({ title, value, icon: Icon }) => (
    <div className="p-6 rounded-xl border bg-white">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
        <div className="p-3 rounded-lg">
          <Icon className="w-6 h-6 text-gray-700" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Quản lý ngày nghỉ</h1>
          <p className="text-gray-600 mt-1">Quản lý đơn xin nghỉ và lịch nghỉ của nhân viên</p>
        </div>

        <button onClick={openCreate} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors">
          <Plus className="w-4 h-4" />
          Tạo đơn nghỉ mới
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatCard title="Tổng đơn nghỉ" value={stats.total}    icon={FileText} />
        <StatCard title="Chờ duyệt"     value={stats.pending}  icon={Clock} />
        <StatCard title="Đã duyệt"      value={stats.approved} icon={Check} />
        <StatCard title="Từ chối"       value={stats.rejected} icon={X} />
      </div>

      {/* FilterBar */}
      <FilterBar
        query={query}
        onQueryChange={setQuery}
        filters={filters}
        onFiltersChange={setFilters}
        schema={[
          { key: 'type',     label: 'Loại nghỉ',  options: types },
          { key: 'status',   label: 'Trạng thái', options: statuses },
          { key: 'approver', label: 'Người duyệt', options: approvers },
        ]}
        placeholder="Tìm theo tên nhân viên, loại nghỉ..."
        className="mb-4"
      />

      {/* Form thêm/sửa */}
      {showForm && (
        <div className="mb-6">
          <LeaveForm initial={editing} onSave={handleSave} onCancel={() => { setShowForm(false); setEditing(null); }} />
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">Danh sách đơn xin nghỉ</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nhân viên</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Loại nghỉ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Thời gian</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Số ngày</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng thái</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Người duyệt</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filtered.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold mr-3">
                        {r.avatar || (r.employeeName ? r.employeeName.charAt(0) : '?')}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{r.employeeName}</div>
                        <div className="text-sm text-gray-500">{r.employeeId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getLeaveTypeColor(r.leaveType)}`}>
                      {r.leaveType}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div>{r.startDate}</div>
                    <div className="text-gray-500">đến {r.endDate}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{r.days} ngày</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(r.status)}`}>
                      {r.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{r.approver}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center gap-2">
                      {r.status === 'Chờ duyệt' && (
                        <>
                          <button title="Duyệt"  onClick={() => setStatus(r.id, 'Đã duyệt')} className="text-green-600 hover:text-green-800"><Check className="w-4 h-4" /></button>
                          <button title="Từ chối" onClick={() => setStatus(r.id, 'Từ chối')}  className="text-red-600 hover:text-red-800"><X className="w-4 h-4" /></button>
                        </>
                      )}
                      <button title="Sửa" onClick={() => openEdit(r.id)} className="text-yellow-600 hover:text-yellow-800"><Edit className="w-4 h-4" /></button>
                      <button title="Xoá" onClick={() => handleDelete(r.id)} className="text-red-600 hover:text-red-800"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Không tìm thấy đơn xin nghỉ nào</p>
          </div>
        )}
      </div>

      {/* Lịch nghỉ (placeholder) */}
      <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Lịch nghỉ tháng này</h3>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Lịch nghỉ sẽ được hiển thị ở đây</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeaveManagementPage;
