import React, { useState } from 'react';
import { BarChart3, TrendingUp, TrendingDown, DollarSign, Users, Calendar, Download, Filter, RefreshCw, FileText, PieChart, LineChart } from 'lucide-react';

const ReportPage = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedReport, setSelectedReport] = useState('performance');

  // Mock data cho báo cáo
  const financialData = {
    revenue: 2450000,
    expense: 1850000,
    profit: 600000,
    growth: 12.5
  };

  const employeeData = {
    total: 25,
    active: 23,
    onLeave: 2,
    newHires: 3
  };

  const taskData = {
    completed: 45,
    inProgress: 12,
    overdue: 3,
    total: 60
  };

  const monthlyData = [
    { month: 'T1', revenue: 2100000, expense: 1600000 },
    { month: 'T2', revenue: 2300000, expense: 1700000 },
    { month: 'T3', revenue: 2200000, expense: 1650000 },
    { month: 'T4', revenue: 2450000, expense: 1850000 },
    { month: 'T5', revenue: 2600000, expense: 1900000 },
    { month: 'T6', revenue: 2750000, expense: 2000000 }
  ];

  const reportTypes = [
    { id: 'employee', name: 'Báo cáo nhân sự', icon: Users },
    { id: 'task', name: 'Báo cáo công việc', icon: FileText },
    { id: 'performance', name: 'Báo cáo hiệu suất', icon: TrendingUp }
  ];

  const periods = [
    { id: 'week', name: 'Tuần này' },
    { id: 'month', name: 'Tháng này' },
    { id: 'quarter', name: 'Quý này' },
    { id: 'year', name: 'Năm này' }
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  const StatCard = ({ title, value, change, icon: Icon, color = 'blue' }) => {
    const isPositive = change > 0;
    const colorClasses = {
      blue: 'bg-blue-50 border-blue-200',
      green: 'bg-green-50 border-green-200',
      red: 'bg-red-50 border-red-200',
      yellow: 'bg-yellow-50 border-yellow-200'
    };

    return (
      <div className={`p-6 rounded-xl border ${colorClasses[color]}`}>
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-lg bg-${color}-100`}>
            <Icon className={`w-6 h-6 text-${color}-600`} />
          </div>
          <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {Math.abs(change)}%
          </div>
        </div>
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
      </div>
    );
  };

  const ChartCard = ({ title, children }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">{title}</h3>
      {children}
    </div>
  );

  const renderEmployeeReport = () => (
    <div className="space-y-6">
      {/* Employee Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Tổng nhân viên"
          value={employeeData.total}
          change={8.3}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Đang làm việc"
          value={employeeData.active}
          change={5.1}
          icon={TrendingUp}
          color="green"
        />
        <StatCard
          title="Đang nghỉ"
          value={employeeData.onLeave}
          change={-12.5}
          icon={Calendar}
          color="yellow"
        />
        <StatCard
          title="Tuyển mới"
          value={employeeData.newHires}
          change={25.0}
          icon={TrendingUp}
          color="green"
        />
      </div>

      {/* Employee Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Phân bổ nhân viên theo phòng ban">
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <PieChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Biểu đồ phân bổ nhân viên</p>
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Xu hướng tuyển dụng">
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <LineChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Biểu đồ xu hướng tuyển dụng</p>
            </div>
          </div>
        </ChartCard>
      </div>
    </div>
  );

  const renderTaskReport = () => (
    <div className="space-y-6">
      {/* Task Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Tổng công việc"
          value={taskData.total}
          change={15.2}
          icon={FileText}
          color="blue"
        />
        <StatCard
          title="Hoàn thành"
          value={taskData.completed}
          change={22.1}
          icon={TrendingUp}
          color="green"
        />
        <StatCard
          title="Đang thực hiện"
          value={taskData.inProgress}
          change={-8.3}
          icon={RefreshCw}
          color="yellow"
        />
        <StatCard
          title="Quá hạn"
          value={taskData.overdue}
          change={-25.0}
          icon={TrendingDown}
          color="red"
        />
      </div>

      {/* Task Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Tiến độ công việc">
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Biểu đồ tiến độ công việc</p>
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Hiệu suất theo nhân viên">
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <LineChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Biểu đồ hiệu suất nhân viên</p>
            </div>
          </div>
        </ChartCard>
      </div>
    </div>
  );

  const renderPerformanceReport = () => (
    <div className="space-y-6">
      <ChartCard title="Báo cáo hiệu suất tổng quan">
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Báo cáo hiệu suất đang được phát triển</p>
          </div>
        </div>
      </ChartCard>
      {/* Bảng chi tiết hiệu suất theo nhân viên */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Chi tiết hiệu suất</h3>
          <div className="text-sm text-gray-500">Kỳ: {selectedPeriod === 'month' ? 'Tháng này' : selectedPeriod}</div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nhân viên</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hoàn thành đúng hạn</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Điểm chất lượng</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Task đang mở</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Điểm tổng</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {[
                { name: 'Nguyễn A', ontime: 95, quality: 92, open: 3, score: 91 },
                { name: 'Trần B', ontime: 88, quality: 85, open: 5, score: 86 },
                { name: 'Lê C', ontime: 90, quality: 89, open: 4, score: 88 },
                { name: 'Phạm D', ontime: 80, quality: 83, open: 7, score: 82 },
              ].map((row, idx) => (
                <tr key={idx}>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{row.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{row.ontime}%</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{row.quality}%</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{row.open}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{row.score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          Gợi ý: Ưu tiên hỗ trợ các cá nhân có <span className="font-medium">điểm tổng &lt; 85</span> và <span className="font-medium">task đang mở &gt; 5</span>.
        </div>
      </div>
    </div>
  );

  const renderReportContent = () => {
    switch (selectedReport) {
      case 'employee':
        return renderEmployeeReport();
      case 'task':
        return renderTaskReport();
      case 'performance':
        return renderPerformanceReport();
      default:
        return renderPerformanceReport();
    }
  };


  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Báo cáo</h1>
          <p className="text-gray-600 mt-1">Tổng quan và phân tích dữ liệu kinh doanh</p>
        </div>

        <div className="flex items-center gap-3">
          <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-200 transition-colors">
            <Filter className="w-4 h-4" />
            Bộ lọc
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors">
            <Download className="w-4 h-4" />
            Xuất báo cáo
          </button>
        </div>
      </div>

      {/* Report Type Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {reportTypes.map((type) => {
              const IconComponent = type.icon;
              return (
                <button
                  key={type.id}
                  onClick={() => setSelectedReport(type.id)}
                  className={`flex items-center gap-2 border-b-2 py-2 px-1 text-sm font-medium whitespace-nowrap ${selectedReport === type.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                >
                  <IconComponent className="w-4 h-4" />
                  {type.name}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Period Selector */}
      <div className="mb-6">
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-gray-700">Thời gian:</span>
          <div className="flex bg-gray-100 rounded-lg p-1">
            {periods.map((period) => (
              <button
                key={period.id}
                onClick={() => setSelectedPeriod(period.id)}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${selectedPeriod === period.id
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                {period.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Report Content */}
      {renderReportContent()}

    </div>
  );
};

export default ReportPage;

