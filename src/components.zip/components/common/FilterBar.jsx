import React, { useMemo, useState } from 'react';
import { Search, Filter, X } from 'lucide-react';

export default function FilterBar({
  query, onQueryChange,
  filters, onFiltersChange,
  schema,            // [{ key:'department', label:'Phòng ban', options:['all','Phòng Kế toán', ...] }, ...]
  placeholder = 'Tìm kiếm...',
  className = ''
}) {
  const [open, setOpen] = useState(false);

  const handleSelect = (key, value) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const clearFilters = () => onFiltersChange(
    Object.fromEntries(Object.keys(filters).map(k => [k, 'all']))
  );
  const clearQuery = () => onQueryChange('');

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-4 ${className}`}>
      <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        {/* Search */}
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder={placeholder}
            className="w-full pl-9 pr-9 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {query && (
            <button
              onClick={clearQuery}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-gray-100"
              title="Xoá tìm kiếm"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
        </div>

        {/* Toggle filter panel */}
        <div className="flex items-center gap-2">
          <button
            className="px-4 py-2 border border-gray-300 rounded-lg flex items-center gap-2 hover:bg-gray-50 transition-colors"
            onClick={() => setOpen(v => !v)}
          >
            <Filter className="w-4 h-4" />
            Bộ lọc
          </button>
        </div>
      </div>

      {open && (
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {schema.map(({ key, label, options }) => (
            <div key={key}>
              <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
              <select
                value={filters[key]}
                onChange={(e) => handleSelect(key, e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {options.map(v => (
                  <option key={v} value={v}>
                    {v === 'all' ? 'Tất cả' : v}
                  </option>
                ))}
              </select>
            </div>
          ))}

          <div className="sm:col-span-3 flex justify-end gap-2">
            <button
              className="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-50"
              onClick={clearFilters}
            >
              Xoá lọc
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
