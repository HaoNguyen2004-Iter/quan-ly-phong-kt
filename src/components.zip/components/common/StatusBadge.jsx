import React from 'react';
import { TASK_STATUS, STATUS_LABEL_VI } from '../../constants/taskStatus';

const StatusBadge = ({ status }) => {
  const label = STATUS_LABEL_VI[status] || status;
  let cls = 'bg-gray-100 text-gray-700';
  if (status === TASK_STATUS.DONE) cls = 'bg-green-100 text-green-700';
  else if (status === TASK_STATUS.OVERDUE) cls = 'bg-red-100 text-red-700';
  else if (status === TASK_STATUS.IN_PROGRESS) cls = 'bg-blue-100 text-blue-700';

  return <span className={`px-2 py-0.5 text-xs rounded-md ${cls}`}>{label}</span>;
};

export default StatusBadge;
