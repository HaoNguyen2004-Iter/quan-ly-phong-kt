import React from 'react';
import { CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const TaskCard = ({ type, title, tasks, count }) => {
  const getCardStyles = () => {
    switch (type) {
      case 'todo':
        return {
          bg: 'bg-blue-50',
          border: 'border-blue-200',
          icon: <CheckCircle className="w-5 h-5 text-blue-600" />,
          titleColor: 'text-blue-800'
        };
      case 'in-progress':
        return {
          bg: 'bg-yellow-50',
          border: 'border-yellow-200',
          icon: <Clock className="w-5 h-5 text-yellow-600" />,
          titleColor: 'text-yellow-800'
        };
      case 'overdue':
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          icon: <AlertTriangle className="w-5 h-5 text-red-600" />,
          titleColor: 'text-red-800'
        };
      default:
        return {
          bg: 'bg-gray-50',
          border: 'border-gray-200',
          icon: <CheckCircle className="w-5 h-5 text-gray-600" />,
          titleColor: 'text-gray-800'
        };
    }
  };

  const styles = getCardStyles();

  return (
    <div className={`${styles.bg} ${styles.border} border rounded-xl p-6 flex flex-col gap-4`}>
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className={`text-lg font-semibold ${styles.titleColor}`}>{title}</div>
        <div className="p-2 bg-white rounded-lg shadow-sm">
          {styles.icon}
        </div>
      </div>

      {/* Task List */}
      <div className="flex flex-col gap-3">
        {tasks.map((task, index) => (
          <div key={index} className="bg-white rounded-lg p-4 shadow-sm">
            {type === 'todo' && (
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="font-medium text-gray-800">{task.name}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    <span className="font-medium">Hạn:</span> {task.deadline}
                  </div>
                </div>
              </div>
            )}

            {type === 'in-progress' && (
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div className="font-medium text-gray-800">{task.name}</div>
                
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Người thực hiện:</span> {task.assignee}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  
                </div>
              </div>
            )}

            {type === 'overdue' && (
              <div className="space-y-2">
                <div className="font-medium text-gray-800">{task.name}</div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-red-600 font-medium">Quá hạn</span>
                  <span className="text-red-600">{task.overdueDays}</span>
                  <span className="text-red-600">ngày</span>
                </div>
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Hạn:</span> {task.deadline}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Count */}
      <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
        <span className="font-medium">Tổng:</span>
        <span className="font-semibold text-gray-800">{count}</span>
        <span>công việc</span>
      </div>
    </div>
  );
};

export default TaskCard;

