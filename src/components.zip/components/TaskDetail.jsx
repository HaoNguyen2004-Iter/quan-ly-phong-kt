import React, { useMemo } from 'react';
import { CheckCircle } from 'lucide-react';
import { useTasksStore } from '../store/tasksStore';
import { TASK_STATUS, STATUS_LABEL_VI, statusOptionsVI } from '../constants/taskStatus';
import StatusBadge from './common/StatusBadge';

const TaskDetail = ({ taskId, onBack, onEdit, onComplete }) => {
  const byId = useTasksStore(s => s.byId);
  const updateTask = useTasksStore(s => s.update);
  const task = useMemo(() => byId?.(taskId), [byId, taskId]);

  if (!task) {
    return (
      <div className="p-6">
        <div className="text-gray-500 text-sm mb-3">Không tìm thấy công việc.</div>
        <button onClick={onBack} className="px-3 py-2 rounded-lg border">Quay lại</button>
      </div>
    );
  }

  const isDone = task.status === TASK_STATUS.DONE;

  const setStatus = (newStatus) => {
    const patch = { id: task.id, status: newStatus };
    if (newStatus === TASK_STATUS.DONE) patch.completedAt = new Date().toISOString();
    updateTask(patch);
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">{task.name}</h2>
        <div className="flex items-center gap-2">
          {!isDone && (
            <button
              onClick={() => (onComplete ? onComplete(task.id) : setStatus(TASK_STATUS.DONE))}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700"
              title="Xác nhận đã hoàn thành"
            >
              <CheckCircle className="w-4 h-4" />
              Hoàn thành
            </button>
          )}
          <button onClick={() => onEdit?.(task.id)} className="px-3 py-2 rounded-lg border">Sửa</button>
          <button onClick={onBack} className="px-3 py-2 rounded-lg border">Quay lại</button>
        </div>
      </div>

      <div className="text-sm text-gray-600 flex items-center gap-2">
        Trạng thái: <StatusBadge status={task.status} />
        {/* Dropdown đổi trạng thái (VI) */}
        <select
          className="ml-2 border rounded-lg p-1.5 text-xs"
          value={task.status}
          onChange={(e) => setStatus(e.target.value)}
        >
          {statusOptionsVI.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>

        {task.completedAt && <span>• Hoàn thành lúc: {new Date(task.completedAt).toLocaleString()}</span>}
      </div>

      {task.description && (
        <div className="bg-white border rounded-xl shadow-sm p-4">
          <div className="text-gray-700 whitespace-pre-line">{task.description}</div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {task.dueDate && (
          <div className="bg-white border rounded-xl shadow-sm p-4">
            <div className="text-xs text-gray-500">Hạn</div>
            <div className="font-medium">{task.dueDate}</div>
          </div>
        )}
        {task.assignee && (
          <div className="bg-white border rounded-xl shadow-sm p-4">
            <div className="text-xs text-gray-500">Phụ trách</div>
            <div className="font-medium">{task.assignee}</div>
          </div>
        )}
        {task.assigneeEmail && (
          <div className="bg-white border rounded-xl shadow-sm p-4">
            <div className="text-xs text-gray-500">Email</div>
            <div className="font-medium">{task.assigneeEmail}</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskDetail;
