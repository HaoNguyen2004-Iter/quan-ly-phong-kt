import React, { useState } from 'react';

const MyLeave = () => {
  const [requests, setRequests] = useState([]);
  const [form, setForm] = useState({ from: '', to: '', reason: '' });

  const submit = (e) => {
    e.preventDefault();
    if (!form.from || !form.to) return;
    setRequests(prev => [{ id: Date.now(), ...form, status: 'Chờ duyệt' }, ...prev]);
    setForm({ from: '', to: '', reason: '' });
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">Nghỉ phép của tôi</h2>

      <form onSubmit={submit} className="bg-white border rounded-xl shadow-sm p-4 mb-6 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input type="date" className="border rounded-lg p-2" value={form.from}
            onChange={e => setForm(f => ({...f, from: e.target.value}))}/>
          <input type="date" className="border rounded-lg p-2" value={form.to}
            onChange={e => setForm(f => ({...f, to: e.target.value}))}/>
          <input type="text" className="border rounded-lg p-2" placeholder="Lý do" value={form.reason}
            onChange={e => setForm(f => ({...f, reason: e.target.value}))}/>
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Gửi đơn</button>
      </form>

      <div className="space-y-3">
        {requests.length === 0 && <div className="text-gray-500 text-sm">Chưa có đơn nào.</div>}
        {requests.map(r => (
          <div key={r.id} className="p-4 bg-white border rounded-xl shadow-sm">
            <div className="font-medium">{r.from} → {r.to}</div>
            <div className="text-sm text-gray-600">{r.reason || '—'}</div>
            <div className="text-sm">Trạng thái: <span className="font-medium">{r.status}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyLeave;
