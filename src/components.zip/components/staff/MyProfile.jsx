import React, { useEffect, useState } from "react";
import { getMyProfile, updateMyProfile } from "../../services/profile";

export default function MyProfile() {
  const [loading, setLoading] = useState(true);
  const [p, setP] = useState(null);
  const [err, setErr] = useState("");

  const load = async () => {
    setLoading(true);
    setErr("");
    try {
      const data = await getMyProfile();
      setP(data);
    } catch {
      setErr("Không tải được hồ sơ");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const onChange = (e) => setP({ ...p, [e.target.name]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    try {
      await updateMyProfile(p);
      alert("Đã lưu hồ sơ");
    } catch {
      alert("Lưu thất bại");
    }
  };

  if (loading) return <div className="p-6">Đang tải...</div>;
  if (err) return <div className="p-6 text-red-600">{err}</div>;
  if (!p) return null;

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-xl font-semibold">Hồ sơ cá nhân</h1>
      <form onSubmit={save} className="bg-white border rounded-xl p-4 grid gap-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Họ tên</label>
            <input name="fullName" value={p.fullName || ""} onChange={onChange} className="border rounded px-3 py-2 w-full" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Điện thoại</label>
            <input name="phone" value={p.phone || ""} onChange={onChange} className="border rounded px-3 py-2 w-full" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Địa chỉ</label>
            <input name="address" value={p.address || ""} onChange={onChange} className="border rounded px-3 py-2 w-full" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Vị trí</label>
            <input name="position" value={p.position || ""} onChange={onChange} className="border rounded px-3 py-2 w-full" />
          </div>
        </div>
        <div>
          <button className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">Lưu</button>
        </div>
      </form>
    </div>
  );
}
