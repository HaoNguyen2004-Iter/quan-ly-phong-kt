import React, { useMemo, useState } from 'react';
import { Users, Plus, Eye, Edit, Trash2 } from 'lucide-react';
import FilterBar from './common/FilterBar';
import { useEmployeesStore } from '../store/employeesStore';

const EmployeePage = ({ onViewEmployee, onAddEmployee, onEditEmployee }) => {
  // lấy data từ store
  const employees = useEmployeesStore(s => s.items);
  const remove = useEmployeesStore(s => s.remove);

  // state filter/search
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState({
    department: 'all',
    position: 'all',
    status: 'all',
  });

  // options cho filter
  const departments = useMemo(
    () => ['all', ...Array.from(new Set(employees.map(e => e.department)))],
    [employees]
  );
  const positions = useMemo(
    () => ['all', ...Array.from(new Set(employees.map(e => e.position)))],
    [employees]
  );
  const statuses = useMemo(
    () => ['all', ...Array.from(new Set(employees.map(e => e.status)))],
    [employees]
  );

  // lọc
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return employees.filter(e => {
      const hit =
        !q ||
        e.name.toLowerCase().includes(q) ||
        e.email.toLowerCase().includes(q) ||
        e.phone.toLowerCase().includes(q);

      if (!hit) return false;
      if (filters.department !== 'all' && e.department !== filters.department) return false;
      if (filters.position !== 'all' && e.position !== filters.position) return false;
      if (filters.status !== 'all' && e.status !== filters.status) return false;

      return true;
    });
  }, [employees, query, filters]);

  const statusPill = s => {
    if (s === 'Đang làm việc') return 'bg-green-100 text-green-800';
    if (s === 'Tạm nghỉ') return 'bg-yellow-100 text-yellow-800';
    return 'bg-gray-200 text-gray-700';
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
        <div className="flex items-center gap-2">
          <Users className="w-6 h-6 text-gray-700" />
          <h1 className="text-2xl font-bold text-gray-800">Danh sách nhân viên</h1>
        </div>
        <button
          onClick={onAddEmployee}
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Thêm nhân viên
        </button>
      </div>

      {/* FilterBar */}
      <FilterBar
        query={query}
        onQueryChange={setQuery}
        filters={filters}
        onFiltersChange={setFilters}
        schema={[
          { key: 'department', label: 'Phòng ban', options: departments },
          { key: 'position', label: 'Chức vụ', options: positions },
          { key: 'status', label: 'Trạng thái', options: statuses },
        ]}
        placeholder="Tìm theo tên, email, số điện thoại..."
        className="mb-4"
      />

      {/* Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nhân viên</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phòng ban</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Chức vụ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Liên hệ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng thái</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filtered.map(e => (
                <tr key={e.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{e.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{e.department}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{e.position}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{e.email}</div>
                    <div className="text-sm text-gray-500">{e.phone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${statusPill(
                        e.status
                      )}`}
                    >
                      {e.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onViewEmployee && onViewEmployee(e.id)}
                        className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800"
                        title="Xem chi tiết"
                      >
                        <Eye className="w-4 h-4" /> Xem
                      </button>
                      <button
                        onClick={() => onEditEmployee && onEditEmployee(e.id)}
                        className="inline-flex items-center gap-1 text-gray-600 hover:text-gray-900"
                        title="Sửa"
                      >
                        <Edit className="w-4 h-4" /> Sửa
                      </button>
                      <button
                        onClick={() => remove(e.id)}
                        className="inline-flex items-center gap-1 text-red-600 hover:text-red-800"
                        title="Xoá"
                      >
                        <Trash2 className="w-4 h-4" /> Xoá
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-gray-500">
                    Không có nhân viên nào khớp điều kiện.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default EmployeePage;
